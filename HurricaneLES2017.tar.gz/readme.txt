README for CM1C_31mdata.tar, a collection of 3721 netCDF files from a Cat 5 hurricane.

Model output from CM1C "Complex" model, idealized Category 5 hurricane 

Simulations ran by George Bryan (gbryan@ucar.edu)
Post-processed by Rochelle Worsnop (Rochelle.Worsnop@ucar.edu)

Please contact Rochelle, George, or Julie Lundquist (Julie.Lundquist@colorado.edu)
with questions.

Publications or presentations resulting from the use of these data should cite:

Worsnop, R. P., J. K. Lundquist, G. H. Bryan, R. Damiani, and W. Musial (2017), 
Gusts and shear within hurricane eyewalls can exceed offshore wind turbine design 
standards, Geophys. Res. Lett., 44, 6413–6420, doi:10.1002/2017GL073537.

These simulations are from the 31-m Complex run. 
(Outer domain = 3000 x 3000 x 25 km: fine mesh domain = 80 x 80 x 3km).
Horizontal grid spacing = 31.25 m, vertical grid spacing = 15.635 m, dt = 0.1875 s, 
altitudes: 7.81 m - 507.81 m 

Simulation was run for 4 hours to reach steady-state. 

Ten additional minutes were output and those data are in this directory. 
These data are output on a grid (not radii) every 1 km in x and every 
1 km in y (processed every 4th file in x and y).

Data are output over a 30 km x 30 km grid (i.e., max radius from the eye is 30 km). 

3721 files total: each file includes data for one virtual tower at 33 heights
over 3201 timesteps. 

Files are named gp_xXXX_yYYY.nc, indicating the XXXth x location and the YYYth y location.

ncdump -h of one file:

jklgroup:/data/fielddata/HurricaneLES>ncdump -h gp_x045_y241.nc 
netcdf gp_x045_y241 {
dimensions:
	ni = 1 ;
	nj = 1 ;
	nk = 33 ;
	nkp1 = 33 ;
	time = UNLIMITED ; // (3201 currently)
variables:
	float xh(ni) ;
		xh:def = "west-east location of scalar grid points" ;
		xh:units = "m" ;
	float yh(nj) ;
		yh:def = "south-north location of scalar grid points" ;
		yh:units = "m" ;
	float zh(nk) ;
		zh:def = "height of scalar grid points" ;
		zh:units = "m" ;
	float zf(nkp1) ;
		zf:def = "height of w grid points" ;
		zf:units = "m" ;
	float time(time) ;
		time:def = "time since beginning of simulation" ;
		time:units = "seconds" ;
	float u10(time) ;
		u10:def = "velocity in x-direction at 10 m MSL" ;
		u10:units = "m/s" ;
	float v10(time) ;
		v10:def = "velocity in y-direction at 10 m MSL" ;
		v10:units = "m/s" ;
	float ust(time) ;
		ust:def = "friction velocity" ;
		ust:units = "m/s" ;
	float znt(time) ;
		znt:def = "roughness length" ;
		znt:units = "m" ;
	float ust2(time) ;
		ust2:def = "instantaneous friction velocity" ;
		ust2:units = "m" ;
	float u(time, nk) ;
		u:def = "velocity in x-direction (interpolated to scalar points)" ;
		u:units = "m/s" ;
	float v(time, nk) ;
		v:def = "velocity in y-direction (interpolated to scalar points)" ;
		v:units = "m/s" ;
	float w(time, nk) ;
		w:def = "vertical velocity (interpolated to scalar points)" ;
		w:units = "m/s" ;
}


